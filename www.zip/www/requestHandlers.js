/**
 * ToyMat request Handlers 
 */
var fs = require("fs");
var querystring = require("querystring");
var dataHandlers = require("./dataHandlers");

function support(response, request) {
	if (request.method === 'POST') {
		 request.setEncoding('utf8');
		 request.on('data', function(chunk) {
			  // there is some data to read now
			 dataHandlers.configController(querystring.parse(chunk));
		 });
	 }
	var configData = dataHandlers.getConfigData(function(configData){
		var rowsId = 'r' + configData.rows.toString();
		var columnsId = 'c' + configData.columns.toString();
		var eqThId = 'eqTh';
		var bytesId = 'b' + configData.bytes.toString();
		var gainId = 'g' + configData.pgaGain.toString();
		var head = '<!DOCTYPE html>'+
		'<html>'+
		'<head>'+
			'<meta charset="ISO-8859-1">'+
			'<title>ToyMat support</title>'+
			'<script>'+
			'function myFunction() {'+
				'document.getElementById("serial").innerHTML = "'+configData.serialNumber+'";'+
				'var rowId = document.getElementById("'+rowsId+'");'+
				'rowId.checked="checked";'+
				'var colId = document.getElementById("'+columnsId+'");'+
				'colId.checked="checked";'+
				'var eqThId = document.getElementById("'+eqThId+'");'+
				'eqThId.value='+configData.eqThreshold.toString()+';'+
				'var bytesId = document.getElementById("'+bytesId+'");'+
				'bytesId.checked="checked";'+
				'var gainId = document.getElementById("'+gainId+'");'+
				'gainId.checked="checked";'+
			'}'+
			'</script>'	+
		'</head>';
		response.writeHead(200, {"Content-Type": "text/html"}); 
		response.write(head);
		//fs.createReadStream("./support.html").pipe(response);
		fs.createReadStream("/mnt/sda1/arduino/www/ToyMatv0_3/support.html").pipe(response);	
	});	
}

function streamdata(response, request) {
	 
	response.writeHead(200, {"Content-Type": "text/html"});  
	//fs.createReadStream("./streamdata.html").pipe(response);
	fs.createReadStream("/mnt/sda1/arduino/www/ToyMatv0_3/streamdata.html").pipe(response);
	
}

function patient(response, request) {
	//console.log("sending script stream");	
	response.writeHead(200, {"Content-Type": "text/html"});  
	//fs.createReadStream("./patient.html").pipe(response);
	fs.createReadStream("/mnt/sda1/arduino/www/ToyMatv0_3/patient.html").pipe(response);	
}

function caregiver(response, request) {
	//console.log("sending script stream");	
	response.writeHead(200, {"Content-Type": "text/html"});  
	//fs.createReadStream("./caregiver.html").pipe(response);
	fs.createReadStream("/mnt/sda1/arduino/www/ToyMatv0_3/caregiver.html").pipe(response);
	
}

function showdata(response, request) {
	//console.log("sending script stream");	
	response.writeHead(200, {"Content-Type": "text/html"});  
	//fs.createReadStream("./showdata.js").pipe(response);
	fs.createReadStream("/mnt/sda1/arduino/www/ToyMatv0_3/showdata.js").pipe(response);
	
}

exports.support = support;
exports.streamdata = streamdata;
exports.patient = patient;
exports.caregiver = caregiver;
exports.showdata = showdata;
