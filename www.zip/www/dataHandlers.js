/**
 * ToyMat dataHandlers file
 */
var util = require('util');
var stream = require('stream');
//var async = require('async');

var matController = require("./matController");
var toymat = new matController();
/*var configData = {
		rows : '8', //two chars from 01 to 32
		columns : '8', //two chars from 01 to 32
		eqThreshold : '247', // desired digital output
							 // better if it's equal to pressure in kPa, 
							 // must have three chars from 000 to 999
		bytes : '2', //single char 1 or 2
		pgaGain : '1', //gain parameter for PGA, single char '1' means gain x2 (see PGA datasheet)
		endBytes : '2' //number of bytes at the end of each frame, 2 = dt + newLine char
};
toymat.writeConfigData(configData,'configFile.JSON');*/
var configFile = '/mnt/sda1/arduino/www/ToyMatv0_3/configFile.JSON';
//var configFile = 'configFile.JSON';
toymat.readConfigData(configFile);

function configController(configData){
	toymat.writeConfigData(configData, configFile);
}

function getConfigData(cb){
	toymat.readConfigData(configFile, cb);
}

var actions = {};
actions["checkProtocol"] = 0;
actions["start"] = 1;
actions["nextStep"] = 2;
actions["stop"] = 3;

var patientOnline = false;
function fitTest0(action, ws){
	switch(actions[action]) {
		case actions["stop"]://exit message
			console.log("ending patient session");			
			break;
		case actions["checkProtocol"]://entry message
			if (!patientOnline){
				patientOnline = true;
				console.log("opening patient session");
				return true;
			} else {
				return false;
			}
			break;
		case actions["start"]:
			console.log("starting patient session");
			break;	
		case actions["nextStep"]:
			console.log("next step");
			break;	
	}
	return true;
}

function meanOutput(frame){
	var sum = 0;
	for (var n = 0; n < frame.length; n++){
		sum += toymat.configData.value.dataDecodeFn(frame[n]);
	}
	return Math.round(sum/frame.length);
}

function quadMeanOutput(Frame){
	var suma = [0, 0, 0, 0];
	var rows = Math.floor(Math.sqrt(Frame.length))//toymat.rows;
	var columns = rows;//toymat.columns;
	var halfcols = columns/2;
    var halfrows = rows/2;
    
    var index;
    for (var j=0; j<halfrows; j++){
      for(var i=0; i<halfcols; i++){
        index = j*columns + i;
        suma[0] += Frame[index];
      }
    }
    for (var j=0; j<halfrows; j++){
      for(var i=halfcols; i<columns; i++){
    	index = j*columns + i;
    	suma[1] += Frame[index];
      }
    }
    for (var j=halfrows; j<rows; j++){
      for(var i=0; i<halfcols; i++){
    	index = j*columns + i;
    	suma[2] += Frame[index];
      }
    }
    for (var j=halfrows; j<rows; j++){
      for(var i=halfcols; i<columns; i++){
    	index = j*columns + i;
        suma[3] += Frame[index];
      }
    }
    for (var j=0; j<4; j++){          
      suma[j] /= (halfrows*halfcols);
      suma[j] = Math.round(suma[j]);
    }
	return suma;
}
/*function fullMatrix(Frame){
	var array = new Uint8Array(Frame.length);
	for (var j=0; j<Frame.length; j++){
		
	}
}*/
var transforms = {};
transforms["fullMatrix"] = function(data){return data;};
transforms["meanOutput"] = meanOutput;
transforms["quadMeanOutput"] = quadMeanOutput;

function realTimeStream (sendFunction, transformFunction) { // step 2
  stream.Writable.call(this);
  this.sendFunction = sendFunction;
  this.transformFunction = transformFunction;
}
util.inherits(realTimeStream, stream.Writable); // step 1
realTimeStream.prototype._write = function (chunk, encoding, done) { // step 3	
	if (chunk !== null){
		this.sendFunction.send(JSON.stringify(this.transformFunction(chunk)), function() { });
	}		
	//console.log('chunk = "' + JSON.stringify(this.transformFunction(chunk)) + '"');
	done();
};
var clientStreams = {};
clientStreams.length = function(){
	var len = 0; 
	var obj;
	for (obj in this){
		if (typeof this[obj] === 'object'){
			len++;
		}
	}
	return len;
};

function realTimeStreaming(action, websocket){
	if (websocket !== undefined && websocket.clientID !== undefined && clientStreams[websocket.clientID.toString()] === undefined){
		clientStreams[websocket.clientID.toString()] = new realTimeStream(websocket, transforms[websocket.protocol]); // instanciate your brand new stream
	}
	
	switch(actions[action]) {
		case actions["checkProtocol"]:
			return true;
			break;
		case actions["getSpecs"]:
			console.log("sending controller specs.");
			websocket.send(JSON.stringify(toymat.configData.value), function() { });
			break;
		case actions["start"]:
			if (clientStreams[websocket.clientID.toString()] !== undefined){
				console.log("starting support stream: " + websocket.clientID.toString());				
				toymat.dataStream.pipe(clientStreams[websocket.clientID.toString()]);
				if (clientStreams.length() == 1){
					toymat.start();
				}								
			}					
			break;
		case actions["stop"]:
			if (clientStreams[websocket.clientID.toString()] !== undefined){
				if (clientStreams.length() == 1){
					toymat.stop();
				}
				process.nextTick(function() {
					toymat.dataStream.unpipe(clientStreams[websocket.clientID.toString()]);
					delete clientStreams[websocket.clientID.toString()];
					console.log("ending support stream: " + websocket.clientID.toString() + ' remaining streams: '+ clientStreams.length());
					var message = {"msg" : 'S'};
					websocket.send(JSON.stringify(message));
				});
			}			
			break;	
	}	
}


exports.fitTest0 = fitTest0;
exports.realTimeStreaming = realTimeStreaming;
exports.configController = configController;
exports.getConfigData = getConfigData;

