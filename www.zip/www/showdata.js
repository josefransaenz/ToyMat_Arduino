/**
 * Javascript file of support
 */
var timer;
var ti = 0;
var frames=0;
var array;

/************************ 
 * WebSocket managing 
 * **********************/
var dataProtocol = "fullMatrix";
var ws = {};
var dataSpecs = {};
var myCanvas = {};
function createWS(protocol){
	var host = window.document.location.host.replace(/:.*/, '');
	ws = new WebSocket('ws://' + host + ':8888'+'/support',  protocol);

	ws.onopen = function (event) {
		document.getElementById('msg').innerHTML = 'connected';
		var message = {"action" : 'getSpecs'};
    	ws.send(JSON.stringify(message));
	};
	ws.onmessage = function (event) {
		var bufferData = event.data;
		var data = JSON.parse(bufferData);
		if (data.length === undefined){
			if (data.serialNumber !== undefined && dataSpecs.dimension === undefined){
				var x;
				for (x in data) {
				    dataSpecs[x] = parseInt(data[x]);
				}
				dataSpecs.dimension=dataSpecs.rows*dataSpecs.columns;
				dataSpecs.frameLength=dataSpecs.dimension*dataSpecs.bytes + dataSpecs.endBytes;
				console.log(dataSpecs.frameLength.toString());
				array = new Uint16Array(dataSpecs.dimension);
				for (var i = 0; i < dataSpecs.dimension; i++){
			        array[i] = i*250/1024;
			    } 
				myCanvas = new MatrixCanvas();
			} else if (data.msg !== undefined){
				var msg = data.msg;
				switch(msg) {
				case 'S':
					streaming = false;
					streamButton.innerHTML = "Start";
			        ti=0;
			        frames=0;
					break;
				default: 
					console.log('msg non supported');
				}
			}			
		} else {
			console.log(data.length.toString());
			readData(data);
		}
	};
	ws.onclose = function (event) {
		console.log('closing websocket');
	};
}
createWS(dataProtocol);

// Protocol selection
var protocolSelect=document.getElementById('protocol');
protocolSelect.addEventListener('input', changeProtocol); 
function changeProtocol(){	
	if (streaming){
		streamManager();
	}
	switch(protocolSelect.selectedIndex){
	case 0:
		dataProtocol="fullMatrix";
		break;
	case 1:
		dataProtocol="meanOutput";
		break;
	case 2:
		dataProtocol="quadMeanOutput";
		break;
	}
	ws.close();
	createWS(dataProtocol);
}

//Data saving
var csvData = "0,";
for (var i = 1; i <= dataSpecs.dimension; i++){
	csvData += i.toString() + ",";
	}
csvData += "\n";
function exportToCsv() {
    window.open('data:text/csv;charset=utf-8,' + escape(csvData));
}
var saveButton = document.getElementById('save_button');
saveButton.addEventListener('click', exportToCsv); 

//Stream managing
var runAnimation = {
    value: false
};
var streaming=false;
function showTime(){
	ti = ti + 1;
    //postMessage(i);  
    document.getElementById("time").innerHTML = ti;
}
var date = new Date();
var time = date.getTime();
function streamManager() {
	
	if (ws.readyState !== 1){
		return;
	}
	if (!streaming){
		var message = {"action" : 'start'};
    	ws.send(JSON.stringify(message));
		timer = setInterval(showTime, 1000);
		//initCanvas(dataProtocol);
		streaming = true;
		streamButton.innerHTML = "Stop";
		time = date.getTime();
		runAnimation.value = true;
		animate();
	} else{
		clearInterval(timer);
		var message = {"action" : 'stop'};
    	ws.send(JSON.stringify(message));		
	}
}
var streamButton = document.getElementById('stream_button');
streamButton.addEventListener('click', streamManager);
document.getElementById('myCanvas').addEventListener('click', streamManager);
    
//Data reading
function readData(data){
	var sum =0;
	
	for (var i = 0; i < data.length; ++i){
		 sum = sum + data[i];
		 }
	if (data.length === dataSpecs.frameLength){
		var rowData = data[dataSpecs.dimension].toString() + ",";		
		if (dataSpecs.bytes === 1){	
			console.log("byte1: "+data[0].toString());
			for (var i = 0; i < dataSpecs.dimension; i++){
	            array[i] = (data[i]-40)*4;
	            rowData += array[i].toString() + ",";
	        }
		} else if (dataSpecs.bytes === 2){
			console.log("byte1: "+data[0].toString());
			console.log("byte2: "+data[1].toString());
			var n=0;
			for (var i = 0; i < data.length-dataSpecs.endBytes; i=i+2){
				array[n] = data[i+1]-40 + (data[i]-40)*4;
				n++;
			}
			for (var i = 0; i < dataSpecs.dimension; i++){
	            rowData += array[i].toString() + ",";
	        }	        
		}
		console.log("array1 "+array[0].toString());
        rowData += "\n";
		csvData += rowData;
    }
	document.getElementById('checksum').innerHTML = String(sum);
	document.getElementById('bytes').innerHTML = String(data.length);
	frames = frames +1;				
	document.getElementById('frames').innerHTML = String(frames);       
  
}

//Canvas definition
var MatrixCanvas = function (){
	var canvas = document.getElementById('myCanvas');
	var context = canvas.getContext('2d');
	var dim = 12*32/dataSpecs.rows;
	var myRectangle = {
	  x: 15,
	  y: 10,
	  width: dim,
	  height: dim,
	  borderWidth: 0.01
	};
	context.font = 'normal 8pt Calibri';
	for (var row = 0; row < dataSpecs.rows; row++){
		context.fillText(row.toString(), 0, (row+1)*dim+7);
		context.fillText(row.toString(), 400, (row+1)*dim+7);
		}
	for (var col = 0; col < dataSpecs.columns; col++){
		context.fillText(col.toString(), (col+1)*dim+5, 8);
		context.fillText(col.toString(), (col+1)*dim+5, 404);
		}
	this.draw = function () {
		  var i = 0;
		  var data2plot;
		  for (var row = 0; row < dataSpecs.rows; row++){
		      for (var col = 0; col < dataSpecs.columns; col++){
		    	  data2plot = array[i]/4;  
		    	  context.beginPath();
		    	  context.rect(myRectangle.x+dim*col, myRectangle.y+dim*row, myRectangle.width, myRectangle.height);
		          var br = 0,
		              bg = 0,
		              bb = 0;
		          if (data2plot<50){
		              bb=data2plot*5;
		          } else if (data2plot<100){
		              bb=250;
		              bg=(data2plot-50)*5;
		          } else if (data2plot<150){
		              bg=250;
		              bb=250-(data2plot-100)*5;
		          } else if (data2plot<200){
		              bg=250;
		              br=(data2plot-150)*5;
		          } else if (data2plot<250){
		              bg=250-(data2plot-200)*5;
		              br=250;
		          } else {
		              br=250;
		          }	              
		          var boxcolor = 'rgb(' + br + ',' + bg + ',' + bb + ')';
				  i++;
				  context.fillStyle = boxcolor;//'rgb(255,0,0)';
				  context.fill();
				  context.lineWidth = myRectangle.borderWidth;
				  context.strokeStyle = 'black';
		          context.stroke();
		      }
		  }
	};
};

    
window.requestAnimFrame = (function(callback) {
    return window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame ||
    function(callback) {
      window.setTimeout(callback, 1000 / 60);
    };
})();
      
  

  //Animation
  function animate() {
    if(runAnimation.value) {      
	  myCanvas.draw();
	  // request new frame
      requestAnimFrame(function() {
        animate();
      });
    }
  }
  

  
