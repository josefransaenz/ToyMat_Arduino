/**
 * Index file of ToyMat3 
 */
var server = require("./server");
var router = require("./router");
var requestHandlers = require("./requestHandlers");
var socketServer = require("./socketServer");
var dataHandlers = require("./dataHandlers");

var handle = {};
handle["/"] = requestHandlers.patient;
handle["/patient"] = requestHandlers.patient;
handle["/support"] = requestHandlers.support;
handle["/streamdata"] = requestHandlers.streamdata;
handle["/caregiver"] = requestHandlers.caregiver;
handle["/showdata"] = requestHandlers.showdata;

var socketHandle = {};
socketHandle["startController"] = dataHandlers.startController;
socketHandle["stopController"] = dataHandlers.stopController;
socketHandle["fitTest0"] = dataHandlers.fitTest0;
socketHandle["fullMatrix"] = dataHandlers.realTimeStreaming;
socketHandle["meanOutput"] = dataHandlers.realTimeStreaming;
socketHandle["quadMeanOutput"] = dataHandlers.realTimeStreaming;

socketServer.start(server.start(router.route, handle), socketHandle);

