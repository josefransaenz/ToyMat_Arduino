/**
 * ToyMat matController file
 */
var util = require('util')
	, EventEmitter = require('events').EventEmitter
	, stream = require('stream')
	, Options = require("options")
	, fs = require('fs');

var matController = function (configData){
	var defaultConfigData = {
		serialNumber: 'TYMT001',
		rows : '32', //two chars from 01 to 32
		columns : '32', //two chars from 01 to 32
		eqThreshold : '247', // desired digital output
							 // better if it's equal to pressure in kPa, 
							 // must have three chars from 000 to 999
		bytes : '1', //single char 1 or 2
		pgaGain : '1', //gain parameter for PGA, single char '1' means gain x2 (see PGA datasheet)
		endBytes : '2', //number of bytes at the end of each frame, 2 = dt + newLine char
		dimension : function() {return (parseInt(this.rows)*parseInt(this.columns)).toString();},
		frameSize : function() {return (parseInt(this.dimension()*parseInt(this.bytes)) + parseInt(this.endBytes)).toString();},
		dataDecodeFn : function(data){
			if (this.bytes == '1'){
				if (data <= 32){ return 0;}
				return (data - 1)*4;
			} else if (this.bytes == '2'){
				var data1, data2;
				if (data[0] <= 32){
					data1 = 0;
				} else {
					data1 = (data[0] - 1)*4;
				}
				if (data[1] <= 32){
					data2 = 0;
				} else{
					data2 = data[1] - 32;
				}
				return data1 + data2;
			}
		}
	};
	
	// Create an option object with default value 
    this.configData = new Options(defaultConfigData);  
    
    var states = {
    		idle : 251,
    		acquiring : 252,
    		equilibrating : 253,
    		unknown : 254,
    		stopNode : 255
    		};
    this.state = states.unknown;
    
	this._write = function(data){
		process.stdout.write(data + '\n');
	};
	this._commandstr = {
			stop : "!",
			start : "$~1",
			equilibrate : "$~2",
			acknowledge : "$~3",
			badFrame : "$~4",
			getState : "$~5"
	};
	this._configstr = {
			rows : "$#r",
			columns : "$#c",
			eqThreshold : "$#e",
			bytes : "$#b",
			pgaGain : "$#g"
	};
	this.getState = function(){
		self.state = states.unknown;
		self._write(self._commandstr.getState);
	};
	
	var self = this;
	this._setConfigData = function(){
		self._write(self._configstr.rows + self.configData.value.rows);
		self._write(self._configstr.columns + self.configData.value.columns);
		self._write(self._configstr.eqThreshold + self.configData.value.eqThreshold);
		self._write(self._configstr.bytes + self.configData.value.bytes);
		self._write(self._configstr.pgaGain + self.configData.value.pgaGain);
	};
	this._setConfigData();
	
	this.readConfigData = function(filename, cb){
		self.configData.read(filename, function(err){ // Async
            if(err){ // If error occurs
                console.log("Config file error.");
	        }else{
	        	self._setConfigData();
	        }
            if (typeof cb === 'function'){
            	cb(self.configData.value);
            }
    	});
    };
	this.writeConfigData = function(configData, filename){
		self.configData = self.configData.merge(configData);
		self._setConfigData();
		fs.writeFileSync(filename, JSON.stringify(self.configData.value));
	};
	
	
	
	this._echoStream = function (options) { // step 2
	  stream.Transform.call(this, options);
	};
	util.inherits(this._echoStream, stream.Transform); // step 1
	this._echoStream.prototype._transform = function (chunk, encoding, done) { // step 3	
		//console.log('received chunk = "'+JSON.stringify(chunk)+'"');
		var clen = chunk.length;
		if (clen === parseInt(self.configData.value.frameSize())){ //			
			self._write(self._commandstr.acknowledge);
			//self.emit('frame', chunk);
			this.push(chunk);
		} else if (clen >= 2 && clen <= 4 && chunk[0] >= states.idle){
			self.emit('state', chunk[0]);
		} else{
			self._write(self._commandstr.badFrame);
			console.log("Bad frame: " + clen.toString() + ' bytes. First: "' + chunk[0] + '"');
		}		
		done();
	};
	this.dataStream = new this._echoStream({'decodeStrings' : false}); // instanciate your brand new stream
	//process.stdin.setEncoding('utf8');
	process.stdin.pipe(this.dataStream); //pipe data from standard input
	
	this.on('state',function(state){
		switch(state) {
		case states.idle:
			self.emit('idle');
			break;
		case states.acquiring:
			self.emit('acquiring');
			break;
		case states.stopNode:
			console.log("node ending");
			process.exit();
			break;
		default:
			console.log('other');
		}
	});
	this.start = function (){
		self._write(self._commandstr.start);
		/*function start(){
			//ask Arduino to start acquiring data
			self._write(self._commandstr.start);
			
		}
		self.getState();
		self.once('idle', start);
		self.once('acquiring', function(){
			self.removeListener('iddle', start);
		});*/
	};

	this.stop = function (){
		self._write(self._commandstr.stop);
		self.getState();
		function stop(){
			//ask Arduino to stop sending data
			self._write(self._commandstr.stop);
			self.getState();
			//process.stdin.unpipe(self.dataStream);
		}		
		self.once('acquiring', stop);
		self.once('idle', function(){
			self.removeListener('acquiring', stop);
		});
	};

};

util.inherits(matController, EventEmitter);

matController.readEquilibration = function (err, eqfile){
	//reads Vs vector from arduino controller and write equilibration file to memory card
};

matController.writeEquilibration = function (err, eqfile){
	//read equilibration file from memory card and write Vs vector to arduino controller
};

matController.equilibrateSensors = function (err){
	//ask arduino to start an equilibration
};

//util.inherits(matController, EventEmitter); 

module.exports=matController;


/*
var arduinolink = new matController(configs);//creation and configuration

arduinolink.on('open', function(){
	//to do when arduino is ready and listening
});

arduinolink.equilibrateSensors(function(err){
	//to do when equilibration is finished, error can indicate the number of not-equilibrated sensors	
});

arduinolink.readEquilibration(function(err){
	//to do when reading equilibration data is finished	
});

arduinolink.writeEquilibration(function(err){
	//to do when writing equilibration data is finished	
});

arduinolink.start();//start acquisition
arduinolink.stop();//stop acquisition

arduinolink.on('frame', function(){
	//to do when a frame is received
});

arduinolink.on('error', function(err){
	//to do when a frame is received
});
*/



